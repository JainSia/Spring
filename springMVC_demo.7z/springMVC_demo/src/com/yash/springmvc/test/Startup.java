package com.yash.springmvc.test;

public class Startup {

	public static void main(String[] args) {
		

	}

}
