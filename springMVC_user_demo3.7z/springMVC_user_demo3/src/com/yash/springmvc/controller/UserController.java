package com.yash.springmvc.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;



@Controller
@RequestMapping
public class UserController {
	

	@RequestMapping(value="/hello.ds{username}")
	public ModelAndView Hello(@RequestParam("username") String username) {
		Map<String, String> map = new HashMap<>();
		map.put("name", username);
		return new ModelAndView("welcome", map);
	}

	@RequestMapping("/hii.ds")
	public ModelAndView hii(){
		Map<String, String> map=new HashMap<>();
		map.put("welcome", "Hii");
		return new ModelAndView("welcome", map);
	}
}
