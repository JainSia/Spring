package springcms;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.Before;
import org.junit.Test;

import com.yash.springcms.dao.UserDAO;
import com.yash.springcms.daoimpl.UserDAOImpl;
import com.yash.springcms.model.User;

public class UserDAOImplTest {
	UserDAO userDAO = null;
	User user = null;

	@Before
	public void setUp() {
		userDAO = new UserDAOImpl();
	}

	@Test
	public void test_insert_method_of_UserDAOImpl_return_true_if_user_inserted() {
		boolean result = userDAO.insert(user);
		assertEquals(true, result);
	}

	@Test(expected = NullPointerException.class)
	public void test_insert_method_of_UserDAOImpl_return_false_if_user_is_null() {

		boolean result = userDAO.insert(new User());
		assertEquals(false, result);
	}

	@Test
	public void test_delete_method_of_UserDAOImpl_return_true_if_user_deleted() {
		boolean result = userDAO.delete(5);
		assertEquals(true, result);
	}

	@Test
	public void test_delete_method_of_UserDAOImpl_return_false_if_user_deletion_failed() {
		boolean result = userDAO.delete(100);
		assertEquals(false, result);
	}

	@Test
	public void test_update_method_of_UserDAOImpl_return_false_if_id_is_null() {
		boolean result = userDAO.update(null, user);
		assertEquals(false, result);
	}

	@Test
	public void test_update_method_of_UserDAOImpl_return_true_if_user_is_null() {
		boolean result = userDAO.update(2, null);
		assertEquals(false, result);
	}
	
	@Test
	public void test_list_method_of_UserDAOImpl() {
		List<User> userList=userDAO.showList();	
		for (User user1 : userList) {
			System.out.println(user1.getId());
			System.out.println(user1.getName());
		}
	}
	
	@Test
	public void test_update_method_of_UserDAOImpl_return_true_if_update_return_true() {
		User userToUpdate=new User(2, "sakshi", "y", "s", "y", "sakshi", "147852");
		boolean result = userDAO.update(2, userToUpdate);
		assertEquals(true, result);
	}
}
