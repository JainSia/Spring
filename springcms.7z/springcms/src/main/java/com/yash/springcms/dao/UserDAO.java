package com.yash.springcms.dao;

import java.util.List;

import com.yash.springcms.model.User;

/**
 * This layer work as data layer, and this interface has abstract methods to
 * perform different tasks like insert, update, delete and list all users
 * 
 * @author ayushi.jain
 *
 */
public interface UserDAO {
	/**
	 * This method will insert user in database
	 * 
	 * @param user
	 *            is object of model class user
	 */
	public boolean insert(User user);

	/**
	 * This method will delete particular user from database.
	 * 
	 * @param userId
	 *            is the provided particular id for User
	 */
	public boolean delete(Integer id);

	/**
	 * This method will list users available in database
	 * 
	 * @return list of users
	 */
	public List<User> showList();

	/**
	 * this method will update details of user
	 * 
	 * @param userId
	 *            of particular user that needs to be updated
	 */
	public boolean update(Integer id, User user);
}
