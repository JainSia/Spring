package com.yash.springcms.daoimpl;

import java.util.ArrayList;
import java.util.List;

import org.apache.jasper.tagplugins.jstl.core.ForEach;

import com.yash.springcms.dao.UserDAO;
import com.yash.springcms.model.User;

/**
 * this class will define all the functionalities declared in UserDAO interface
 * 
 * @author saloni.jain
 * @author harmeet.saluja
 */
public class UserDAOImpl implements UserDAO {

	/**
	 * This is local repository of users.
	 */
	private List<User> userRepository = null;

	
	
	public UserDAOImpl() {
		userRepository = new ArrayList<User>();
		userRepository.add(new User(1, "Harmeeet", "hss", "Dewas", "hss", "hss",  "123456"));
		userRepository.add(new User(2, "Saloni", "sj", "Ujjain", "sj", "sj", "98765432"));
	}

	public boolean insert(User user) {
		boolean result=false;
		if (user != null && !user.getName().isEmpty()) {
			userRepository.add(user);
			result=true;
		} 
		return result;
	}

	public boolean delete(Integer id) {
		boolean result = false;
		if (userRepository.isEmpty()) {
			for (User user : userRepository) {
				if (user.getId() == id) {
					userRepository.remove(user);
					result = true;
					break;
				}
			}
			return result;
		} else {
			return result;
		}
	}

	public List<User> showList() {
		List<User> temproryList=new ArrayList();
		for (User user : userRepository) {
			temproryList.add(user);
		}
		return temproryList;
	}

	public boolean update(Integer id, User user) {

		for (User userToUpdate : userRepository) {
			if(userToUpdate.getId()==id){
				userToUpdate.setName(user.getName());
				userToUpdate.setEmail(user.getEmail());
				userToUpdate.setContact(user.getContact());
				userToUpdate.setUsername(user.getUsername());
				userToUpdate.setAddress(user.getAddress());
				userToUpdate.setPassword(user.getPassword());
				return true;
			}
		}
		return false;
	}

}
